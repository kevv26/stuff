# Program Pembalik String

Program Python ini menerima input string dari pengguna dan menampilkan semua karakter string tersebut dalam urutan terbalik.

## Menjalankan Program

Untuk menjalankan program ini, pastikan komputer Anda telah terinstal Python versi 3.6 atau yang lebih baru.

1. Unduh file proyek ke komputer Anda.
2. Buka terminal atau command prompt.
3. Masuk ke direktori yang berisi file program.
4. Jalankan program dengan perintah:

```bash
python string_reverser.py
```

## Cara Menggunakan Program

Setelah program dijalankan, Anda akan diminta untuk memasukkan string yang ingin dibalik. Masukkan string yang diinginkan dan tekan Enter. Program akan menampilkan string yang sudah dibalik.

## Contoh Penggunaan Program

```bash
Masukkan string yang ingin dibalik: Halo dunia!
String yang dibalik: !ainud olaH
```

## Pembuat

Kodland
