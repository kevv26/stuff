def test_sum():
    sum_result = 1 + 2
    assert sum_result == 3