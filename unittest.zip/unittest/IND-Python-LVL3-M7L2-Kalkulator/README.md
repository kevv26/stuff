# Program Kalkulator

Ini adalah program kalkulator.

## Menjalankan Program

Untuk menjalankan program, pastikan Python versi 3.6 atau yang lebih baru sudah terpasang di komputer Anda.

1. Unduh file proyek ke komputer Anda.
2. Buka terminal atau command prompt.
3. Masuk ke direktori yang berisi file program.
4. Jalankan program dengan perintah:

```bash
python calculator_program.py
```

## Penggunaan Program

Setelah menjalankan program, Anda akan diminta untuk memasukkan angka pertama, kemudian angka kedua, lalu operasi yang akan dilakukan di antara keduanya. Masukkan data sesuai permintaan dan tekan Enter. Program akan menampilkan hasilnya.

## Contoh Penggunaan Program

```bash
Masukkan angka pertama: 4
Masukkan angka kedua: 3
Pilih operasi (+, -, *, /): +
Hasil: 7.0
```

## Penulis

Kodland
